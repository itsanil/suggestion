<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSocietyDatasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('society_datas', function (Blueprint $table) {
            $table->id();
            $table->string('address', 255);
            $table->string('email', 255);
            $table->string('gst_no', 255)->nullable();
            $table->string('pt_no', 255)->nullable();
            $table->string('pan_no', 255)->nullable();
            $table->string('tan_no', 255)->nullable();
            $table->string('city', 255)->nullable();
            $table->string('state', 255)->nullable();
            $table->string('pincode', 255)->nullable();
            $table->string('img', 255)->nullable();
            $table->string('registration_number', 255)->nullable();
            $table->string('db_name', 255)->nullable();
            $table->string('db_username', 255)->nullable();
            $table->string('db_password', 255)->nullable();
            $table->bigInteger('mobile_no')->nullable();
            $table->unsignedBigInteger('society_id')->nullable();
            $table->foreign('society_id')->references('id')->on('societies')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('society_datas');
    }
}
