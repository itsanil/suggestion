<?php 
use \App\Models\Module;
 ?>
<div id="sidebar-menu">
    <!-- Left Menu Start -->
    <ul class="metismenu list-unstyled" id="side-menu">
        <li class="menu-title" key="t-menu">Menu</li>
        <li>
            <a href="{{url('home')}}">
                <i class="bx bx-home-circle"></i>
                <span key="t-dashboards">Dashboards</span>
            </a>
        </li>
        <li>
            @role('Admin')
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="bx bx-home-circle"></i>
                <span key="t-dashboards">Master</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="{{url('module')}}" key="t-default">Module</a></li>
                <li><a href="{{url('subscription')}}" key="t-default">Subscription</a></li>
                <li><a href="{{url('society')}}" key="t-default">Society</a></li>
                <li><a href="{{url('roles')}}" key="t-crypto">Roles</a></li>
                <li><a href="{{url('users')}}" key="t-saas">User</a></li>
                
            </ul>
            @endrole
        </li>
        <li>
            @role('Society')
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="bx bx-home-circle"></i>
                <span key="t-dashboards">Module</span>
            </a>
            <?php 
                $module_data = Module::pluck('name','url_name')->toArray();
            ?>
            <ul class="sub-menu" aria-expanded="false">
                @foreach($module_data as $url_name => $name)
                <li><a href="{{url($url_name)}}" key="t-default">{{$name}}</a></li>
                @endforeach
                <li><a href="{{url('subscription')}}" key="t-default">Members</a></li>
            </ul>
            @endrole
        </li>
    </ul>
</div>