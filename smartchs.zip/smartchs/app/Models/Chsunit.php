<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Chsunit extends Model
{
    use HasFactory;
    protected $table = 'chs_unit';
}
