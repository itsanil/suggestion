
<?php $__env->startSection('m1','Subscription'); ?>
<?php $__env->startSection('m2','Edit'); ?>


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    
                    <?php echo Form::model($data, ['method' => 'PATCH','route' => ['subscription.update', $data->id]]); ?>

                       <?php echo $__env->make('subscription.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                    <?php echo Form::close(); ?>

                </div>
            </div>
            <!-- end select2 -->

        </div>


    </div>
    <!-- Button trigger modal -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hrms\smartchs\resources\views/subscription/edit.blade.php ENDPATH**/ ?>