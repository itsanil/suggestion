<div class="row">
    <div class="col-lg-12">
        <div class="form-group">
            <?php echo e(Form::label('text', 'Name', ['class' => 'form-control-label'])); ?>

            <?php echo e(Form::text('name', null, ['class' => 'form-control','required'=>true])); ?>

        </div>
    </div>
    <div class="col-lg-12">
        <div class="form-group">
            <?php echo e(Form::label('text', 'Duration', ['class' => 'form-control-label'])); ?>

            <?php echo e(Form::text('duration', null, ['class' => 'form-control','required'=>true])); ?>

        </div>
    </div>
    <div class="col-lg-12">
        <div class="form-group">
            <?php echo e(Form::label('text', 'Modules', ['class' => 'form-control-label'])); ?>

            <!-- <?php echo e(Form::select('modules', $module_data, null, [ 'class'=> 'form-control', 'placeholder' => 'Select modules...'])); ?> -->
            <?php if(isset($data)): ?>
            <?php echo e(Form::select('modules[]', $module_data,json_decode($data->modules) , [ 'class'=> 'select2 form-control select2-multiple', "multiple"=>"multiple"])); ?>

            <?php else: ?>
            <?php echo e(Form::select('modules[]', $module_data, null, [ 'class'=> 'select2 form-control select2-multiple', "multiple"=>"multiple"])); ?>

            <?php endif; ?>
            <!-- <?php echo e(Form::text('modules', null, ['class' => 'form-control','required'=>true])); ?> -->
        </div>
    </div>
</div>
<br>
<!-- <div class="btn-group mb-12 d-flex" role="group"> -->
    <button type="submit" class="btn btn-primary float-right" data-method="destroy">Save</button>
<!-- </div> --><?php /**PATH C:\xampp\htdocs\hrms\smartchs\resources\views/subscription/form.blade.php ENDPATH**/ ?>