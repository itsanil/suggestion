
<?php $__env->startSection('m1','Society'); ?>
<?php $__env->startSection('m2','Data'); ?>


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <?php echo Form::model($data, ['method' => 'PATCH','route' => ['society.update', $society->id],"enctype"=>"multipart/form-data"]); ?>

                        <input type="hidden" name="society_id" value="<?php echo e($society->id); ?>">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('address', 'Address', ['class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::text('address', null, ['class' => 'form-control','required'=>true])); ?>

                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('email', 'Email', ['class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::email('email', null, ['class' => 'form-control','required'=>true])); ?>

                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('gst_no', 'GST Number', ['class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::text('gst_no', null, ['class' => 'form-control','required'=>true])); ?>

                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('pt_no', 'PT Number', ['class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::text('pt_no', null, ['class' => 'form-control','required'=>true])); ?>

                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('pan_no', 'PAN Number', ['class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::text('pan_no', null, ['class' => 'form-control','required'=>true])); ?>

                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('tan_no', 'TAN Number', ['class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::text('tan_no', null, ['class' => 'form-control','required'=>true])); ?>

                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('city', 'City', ['class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::text('city', null, ['class' => 'form-control','required'=>true])); ?>

                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('state', 'State', ['class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::text('state', null, ['class' => 'form-control','required'=>true])); ?>

                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('pincode', 'Pincode', ['class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::text('pincode', null, ['class' => 'form-control','required'=>true])); ?>

                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">

                                    <?php echo e(Form::label('img', 'Image', ['class' => 'form-control-label'])); ?>

                                    <?php if($data && $data->img): ?>
                                        <a href="<?php echo e(url($data->img)); ?>" target="_blank">
                                            <img src="<?php echo e(asset($data->img)); ?>" alt="" class="avatar-sm">
                                        </a>
                                    <?php endif; ?>
                                    <br>
                                    <?php echo e(Form::file('img', ['class' => 'form-control-file'])); ?>

                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('registration_number', 'Registration Number', ['class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::text('registration_number', null, ['class' => 'form-control','required'=>true])); ?>

                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('db_name', 'Database Name', ['class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::text('db_name', null, ['class' => 'form-control','required'=>true])); ?>

                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('db_username', 'Database Username', ['class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::text('db_username', null, ['class' => 'form-control','required'=>true])); ?>

                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('db_password', 'Database Password', ['class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::text('db_password',  null,['class' => 'form-control','required'=>true])); ?>

                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('mobile_no', 'Mobile Number', ['class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::tel('mobile_no', null, ['class' => 'form-control','required'=>true])); ?>

                                </div>
                            </div>
                        </div>
                        <br>
                        <!-- <div class="btn-group mb-12 d-flex" role="group"> -->
                            <button type="submit" class="btn btn-primary float-right" data-method="destroy">Save</button>
                        <!-- </div> -->
                    <?php echo Form::close(); ?>

                </div>
            </div>
            <!-- end select2 -->

        </div>


    </div>
    <!-- Button trigger modal -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_7\htdocs\hrms\smartchs\resources\views/society/show.blade.php ENDPATH**/ ?>