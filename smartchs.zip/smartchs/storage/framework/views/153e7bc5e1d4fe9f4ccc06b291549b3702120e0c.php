<?php 
use \App\Models\Module;
 ?>
<div id="sidebar-menu">
    <!-- Left Menu Start -->
    <ul class="metismenu list-unstyled" id="side-menu">
        <li class="menu-title" key="t-menu">Menu</li>
        <li>
            <a href="<?php echo e(url('home')); ?>">
                <i class="bx bx-home-circle"></i>
                <span key="t-dashboards">Dashboards</span>
            </a>
        </li>
        <li>
            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Admin')): ?>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="bx bx-home-circle"></i>
                <span key="t-dashboards">Master</span>
            </a>
            <ul class="sub-menu" aria-expanded="false">
                <li><a href="<?php echo e(url('module')); ?>" key="t-default">Module</a></li>
                <li><a href="<?php echo e(url('subscription')); ?>" key="t-default">Subscription</a></li>
                <li><a href="<?php echo e(url('society')); ?>" key="t-default">Society</a></li>
                <li><a href="<?php echo e(url('roles')); ?>" key="t-crypto">Roles</a></li>
                <li><a href="<?php echo e(url('users')); ?>" key="t-saas">User</a></li>
                
            </ul>
            <?php endif; ?>
        </li>
        <li>
            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Society')): ?>
            <a href="javascript: void(0);" class="has-arrow waves-effect">
                <i class="bx bx-home-circle"></i>
                <span key="t-dashboards">Module</span>
            </a>
            <?php 
                $module_data = Module::pluck('name','url_name')->toArray();
            ?>
            <ul class="sub-menu" aria-expanded="false">
                <?php $__currentLoopData = $module_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url_name => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(url($url_name)); ?>" key="t-default"><?php echo e($name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(url('subscription')); ?>" key="t-default">Members</a></li>
            </ul>
            <?php endif; ?>
        </li>
    </ul>
</div><?php /**PATH C:\xampp_7\htdocs\hrms\smartchs\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>